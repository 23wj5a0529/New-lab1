package com.quickstartdev.librarymanagementsystem;

class ApplicationTests {


	void contextLoads() {
	}

}
