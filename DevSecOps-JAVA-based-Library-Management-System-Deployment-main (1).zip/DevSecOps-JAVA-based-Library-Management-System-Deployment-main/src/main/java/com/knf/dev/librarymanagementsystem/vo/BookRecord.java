package com.knf.dev.librarymanagementsystem.vo;

public record BookRecord(Long id, String isbn, String name, String serialName, String description) {
}
